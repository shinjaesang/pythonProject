from sklearn import svm
from sklearn.datasets import load_breast_cancer
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import confusion_matrix
from sklearn import metrics
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = load_breast_cancer(as_frame=True)
print(data.frame)
print(data.data)
print(data.target)
# 데이터 결측치 확인 필수

x_train, x_test, y_train, y_test = train_test_split(data.data, data.target,
                                                    test_size=0.3, random_state=1234)
# print(x_train.shape)
# print(x_test.shape)
# print(y_train.shape)
# print(y_test.shape)

sns.set(rc={'figure.figsize': (31, 31)})
correlation_matrix = data.data.corr().round(2)
sns.heatmap(data=correlation_matrix, annot=True)
plt.show()

data_mean = data.frame[['mean concave points', 'worst radius',
                        'worst perimeter', 'worst concave points',
                        'target']]
sns.pairplot(data_mean, hue='target')
plt.show()

x_train, x_test, y_train, y_test = train_test_split(data_mean[['mean concave points', 'worst radius',
                        'worst perimeter', 'worst concave points']],
                        data_mean['target'],
                        test_size=0.6, random_state=1234)

scalerX = StandardScaler()
scalerX.fit(x_train)
x_train_std = scalerX.transform(x_train)
x_test_std = scalerX.transform(x_test)
print(x_train_std)
print(x_test_std)

clf = svm.SVC(kernel='rbf')
clf.fit(x_train_std, y_train)
# param_grid = {"gamma": np.logspace(-10, 1, 11, base=2),
#                                    "C":[0.5, 1.0, 2.0]}
#
# grid_model = GridSearchCV(clf, param_grid=param_grid, cv=10)
# grid_model.fit(x_train_std, y_train)
# print(grid_model.best_params_)
# clf = svm.SVC(kernel='rbf', C=1, gamma=0.02061731110582648)
# clf.fit(x_train_std, y_train)
# y_pred = clf.predict(x_test_std, y_test)
# print(clf.score(x_test_std, y_test))

y_pred = clf.predict(x_test_std)
print(y_pred)

cf = confusion_matrix(y_test, y_pred)
print(cf)

clf.score(x_test_std, y_test)
print(clf.score(x_test_std, y_test))