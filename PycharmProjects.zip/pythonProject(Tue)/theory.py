import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from sklearn.metrics import mean_squared_error
from sklearn.metrics import mean_squared_error as mse
from sklearn.metrics import mean_absolute_error
from  sklearn import linear_model

#데이터 저장 위치
data_home = 'https://github.com/dknife/ML/raw/main/data/'
lin_data = pd.read_csv(data_home + 'pollution.csv')  #데이터 파일 이름
print(lin_data)
lin_data.plot(kind = 'scatter', x = 'input', y = 'pollution')
# plt.show()

def h(x, w, b):
    return w * x + b

w, b = -3, 6
x0, x1 = 0.0, 0.5

# 데이터(산포도)와 가설(직선)을 비교
lin_data.plot(kind = 'scatter', x = 'input', y = 'pollution')
plt.plot([x0, x1], [h(x0, w, b), h(x1, w, b)])
plt.show()
x = lin_data['inptu']
y = lin_data['pollution']

learning_rate = 0.0025

for i in range(10000):
    y_hat = h(x, w, b)
    error = y_hat - y
    w = w - learning_rate * (error * x).sum()
    b = b - learning_rate * error.sum()

lin_data.plot(kind = 'scatter', x = 'input', y = 'pollution')
plt.plot([x0, x1], [h(x0, w, b), h(x1, w, b)])
plt.show()

y_hat = np.array([1.2, 2.1, 2.9, 4.1, 4.7, 6.3, 7.1, 7.7, 8.5, 10.1])
y = np.array([1,2,3,4,5,6,7,8,9,10])
diff_square = (y_hat - y)**2
e_mse = diff_square.sum() / len(y)
print(e_mse)
# 평균 제곱 오차
print('Mean squared error:', mean_squared_error(y_hat, y))
#오차를 제곱하지 않고 절대값을 취해 더하는 것
print('Mean absolute error:', mean_absolute_error(y_hat, y))

x = np.array([1, 4.5, 9, 10, 13])
y = np.array([0, 0.2, 2.5, 5.4, 7.3])

w_list = np.arange(1.0, 0.2, -0.1)
errors = []

for w in w_list:
    y_hat = w * x
    error = mse(y_hat, y)
    errors.append(error)
    print('w = {:.1f}, 평균제곱 오차: {:.2f}'.format(w, error))

plt.plot(w_list, errors)
plt.xlabel('w')
plt.ylabel('Mean Squared Error')
plt.show()

learning_rate = 0.005
w = w - learning_rate * (error * x).sum()
b = b - learning_rate * error.sum()


def h(x, param):
    return param[0]*x + param[1]

learning_iteration = 1000
learning_rate= 0.0025

param = [1, 1]


x = lin_data['input'].to_numpy()
y = lin_data['pollution'].to_numpy()
for i in range(learning_iteration):
    if i % 200 == 0:
        lin_data.plot(kind = 'scatter', x= 'input', y = 'pollution')
        plt.plot([0, 1], [h(0, param), h(1, param)])
        error = ( h(x, param) - y)
        param[0] -= learning_rate* (error * x).sum()
        param[1] -= learning_rate* error.sum()

