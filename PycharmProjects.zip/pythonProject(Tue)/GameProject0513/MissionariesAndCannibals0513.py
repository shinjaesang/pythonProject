import copy

state = [1,[3,3],[0,0]]
action = [1,0,0]
goal = [2,[0,0],[3,3]]
vistied = []
stack = []
temp = []

#함수선언
#왼쪽에서 오른쪽으로 가는 움직임 반환
def LtoRAction():
    return [[1,1,1],[1,1,0],]