import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score
import matplotlib.pyplot as plt
import seaborn as sns

# 데이터셋 불러오기
file_path = 'C:\\Users\\AI509-18\\PycharmProjects\\pythonProject(mechinlearning_Tue)\\dataset.csv'
data = pd.read_csv(file_path)

# 데이터셋의 첫 몇 행 출력
print("데이터셋의 첫 몇 행:")
print(data.head())
data.head().plot(kind='bar', figsize=(10, 7))
plt.title('First few rows of the dataset')
plt.show()

# 데이터 탐색
print("데이터 정보:")
print(data.info())

print("기술 통계:")
print(data.describe())

# 결측값 확인
print("결측값 확인:")
print(data.isnull().sum())

# 결측값 처리 (숫자형 열에 대해서만 평균으로 대체)
numeric_columns = data.select_dtypes(include=['number']).columns
data[numeric_columns] = data[numeric_columns].fillna(data[numeric_columns].mean())

# 범주형 변수의 결측값 처리 (예: 가장 빈도가 높은 값으로 대체)
categorical_columns = data.select_dtypes(include=['object']).columns
for column in categorical_columns:
    data[column] = data[column].fillna(data[column].mode()[0])

# 결측값이 잘 처리되었는지 확인
print("결측값 확인 (처리 후):")
print(data.isnull().sum())

# 범주형 변수를 더미/인디케이터 변수로 변환
data = pd.get_dummies(data, drop_first=True)

# 데이터 시각화
plt.figure(figsize=(12, 8))
sns.heatmap(data.corr(), annot=True, cmap='coolwarm')
plt.title('Correlation Matrix')
plt.show()

# 이상값 탐지 (숫자형 열에 대해서만 IQR 방법 사용)
Q1 = data[numeric_columns].quantile(0.25)
Q3 = data[numeric_columns].quantile(0.75)
IQR = Q3 - Q1
outliers = (data[numeric_columns] < (Q1 - 1.5 * IQR)) | (data[numeric_columns] > (Q3 + 1.5 * IQR))

# 이상값 개수 출력
print("이상값 개수:")
print(outliers.sum())

# 이상값 처리 (예: 이상값을 중간값으로 대체)
for column in numeric_columns:
    median = data[column].median()
    data[column] = data[column].mask(outliers[column], median)

# 데이터셋을 훈련 세트와 테스트 세트로 분할
X = data.drop('Heart Disease', axis=1)
y = data['Heart Disease']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# 훈련 세트와 테스트 세트의 크기 출력
print("훈련 세트와 테스트 세트의 크기:")
print(X_train.shape, X_test.shape)
fig, ax = plt.subplots()
ax.bar(['X_train', 'X_test'], [X_train.shape[0], X_test.shape[0]])
ax.set_title('Sizes of the training and testing sets')
plt.show()

# 데이터 표준화
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# 표준화된 훈련 세트의 첫 몇 행 출력
print("표준화된 훈련 세트의 첫 몇 행:")
print(X_train[:5])
pd.DataFrame(X_train[:5]).plot(kind='bar', figsize=(10, 7))
plt.title('First few rows of the standardized training set')
plt.show()

# 하이퍼파라미터 튜닝
param_grid = {'C': [0.1, 1, 10, 100], 'gamma': [1, 0.1, 0.01, 0.001], 'kernel': ['linear']}
grid = GridSearchCV(SVC(), param_grid, refit=True, verbose=2)
grid.fit(X_train, y_train)

print("최적 하이퍼파라미터:", grid.best_params_)

# 최적 하이퍼파라미터로 SVM 모델 훈련
svm_model = grid.best_estimator_
svm_model.fit(X_train, y_train)

# 예측 및 평가
y_pred_train = svm_model.predict(X_train)
y_pred_test = svm_model.predict(X_test)

# 평가
train_accuracy = accuracy_score(y_train, y_pred_train)
test_accuracy = accuracy_score(y_test, y_pred_test)
classification_report_train = classification_report(y_train, y_pred_train)
classification_report_test = classification_report(y_test, y_pred_test)

# 평가 결과 출력
print(f'Training Accuracy: {train_accuracy}')
print(f'Test Accuracy: {test_accuracy}')
print(f'Classification Report (Training):\n{classification_report_train}')
print(f'Classification Report (Test):\n{classification_report_test}')

# 정확도 시각화
fig, ax = plt.subplots()
ax.bar(['Train Accuracy', 'Test Accuracy'], [train_accuracy, test_accuracy])
ax.set_ylim(0, 1)
ax.set_title('Training and Test Accuracy')
plt.show()

# 훈련 세트에 대한 분류 보고서 시각화
report_train = pd.DataFrame(classification_report(y_train, y_pred_train, output_dict=True)).transpose()
sns.heatmap(report_train.iloc[:-1, :].T, annot=True)
plt.title('Classification Report (Training)')
plt.show()

# 테스트 세트에 대한 분류 보고서 시각화
report_test = pd.DataFrame(classification_report(y_test, y_pred_test, output_dict=True)).transpose()
sns.heatmap(report_test.iloc[:-1, :].T, annot=True)
plt.title('Classification Report (Test)')
plt.show()

# 혼동 행렬 히트맵 시각화
conf_matrix = pd.crosstab(y_test, y_pred_test, rownames=['Actual'], colnames=['Predicted'])
plt.figure(figsize=(10, 7))
sns.heatmap(conf_matrix, annot=True, fmt='d', cmap="Blues")
plt.title('Confusion Matrix')
plt.show()

# 피처 중요도 평가 (Random Forest 사용)
rf_model = RandomForestClassifier(random_state=42)
rf_model.fit(X_train, y_train)
feature_importances = pd.Series(rf_model.feature_importances_, index=X.columns)
feature_importances.nlargest(10).plot(kind='barh')
plt.title('Top 10 Feature Importances')
plt.show()

# 다양한 모델 비교
models = {
    'Logistic Regression': LogisticRegression(),
    'Random Forest': RandomForestClassifier(),
    'SVM': SVC(kernel='linear')
}

for name, model in models.items():
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f'{name} Test Accuracy: {accuracy}')
    print(f'Classification Report for {name}:\n{classification_report(y_test, y_pred)}')

# 모델 비교 결과 시각화
accuracies = [accuracy_score(y_test, model.predict(X_test)) for model in models.values()]
fig, ax = plt.subplots()
ax.bar(models.keys(), accuracies)
ax.set_ylim(0, 1)
ax.set_title('Model Comparison - Test Accuracy')
plt.show()
