import matplotlib.pyplot as plt
import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn import cluster

dach_length = [77, 78, 85, 83, 73, 77, 73, 80]
dach_height = [25, 28, 29, 30, 21, 22, 17, 35]

samo_length = [75, 77, 86, 86, 79, 83, 83, 88]
samo_height = [56, 57, 50, 53, 60, 53, 49, 61]

newdata_length=[82]
newdata_height=[40]

d_data = np.column_stack((dach_length, dach_height))
d_label = np.zeros(len(d_data)) #닥스훈트를 0으로 구분
s_data = np.column_stack((samo_length, samo_height))
s_label = np.ones(len(s_data)) #사모예드를 1로 구분

newdata = [[82, 40]]

dogs = np.concatenate((d_data, s_data))
labels = np.concatenate((d_label, s_label))

plt.scatter(dach_length, dach_height, c= 'red', label = 'Dachund')
plt.scatter(samo_length, samo_height, c= 'blue', marker='^', label = 'Samoyed')
plt.scatter(newdata_length, newdata_height,marker='p', c= 'green', label = 'new Data')

plt.xlabel('Length')
plt.ylabel('Height')
plt.title('Dog size')
plt.legend(loc='upper left')
# plt.show()
#길이에서의 차이가 없으며 높이에서의 차이가 분명하다



dog_classes = {0:'Dachshund', 1:'Samoyed'}

k = 9
knn = KNeighborsClassifier(n_neighbors = k)
knn.fit(dogs, labels)
y_pred = knn.predict(newdata)
print(('데이터', newdata, ', 판정결과:', dog_classes[y_pred[0]]))


dog_length = np.array(dach_length + samo_length)
dog_height = np.array(dach_height + samo_height)

dog_data = np.column_stack((dog_length, dog_height))

plt.title("Dog data without label")
plt.scatter(dog_length, dog_height)
# plt.show()

def kmeans_preidict_plot(X, k):
    model = cluster.KMeans(n_clusters=k)
    model.fit(X)
    labels = model.predict(X)
    colors = np.array(['red', 'green', 'blue', 'magenta'])  # Color array for consistency
    plt.suptitle('K-Means clustering, k={}'.format(k))

    plt.scatter(X[:, 0], X[:, 1], c=labels, cmap='viridis')

kmeans_preidict_plot(dog_data, k=3)
# kmeans_preidict_plot(dog_data, k=4)
plt.show()