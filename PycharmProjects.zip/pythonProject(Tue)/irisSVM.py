from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import ConfusionMatrixDisplay
from sklearn.metrics import confusion_matrix
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# 2. 데이터 준비
# 데이터 불러오기
from sklearn.datasets import load_iris

data = load_iris(as_frame=True)

# 데이터프레임 출력
print(data.frame)

##3.탐색적 데이터분석
# 데이터 세트 개요
print(data.DESCR)
print(data.target_names)

X = data.frame[['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)']]

correlation_matrix = X.corr().round(2)  # 상관행렬 생성
sns.heatmap(data=correlation_matrix, annot=True)
# plt.show()

# 4단계 데이터 분리
# 학습용과 테스트데이터분리
X_train, X_test, y_train, y_test = train_test_split(X, data.target, test_size=0.3, random_state=1234)

##5.피처 스케일링
# 피처스케일링:학습데이터
scalerX = StandardScaler()
scalerX.fit(X_train)
X_train_std = scalerX.transform(X_train)

# 피처스케일링: 테스트데이터
X_test_std = scalerX.transform(X_test)

##6.모형화 및 학습
# SVM 모델 생성 및 학습
svm_model = SVC(kernel='rbf') #0.5, 0.1, 1.0, 2.0, 0.01, 0.001(rbf)
svm_model.fit(X_train_std, y_train)

# 예측
y_pred = svm_model.predict(X_test_std)
print(y_pred)

# confusion_matrix
cf = confusion_matrix(y_test, y_pred)
print(cf)
ConfusionMatrixDisplay.from_predictions(y_test, y_pred)
# plt.show()

# 테스트데이터에 대한 정확도
accuracy = svm_model.score(X_test_std, y_test)
print(accuracy)
