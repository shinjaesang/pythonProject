import numpy as np
from sklearn.metrics import confusion_matrix
from sklearn.metrics import precision_score, recall_score
from sklearn.metrics import accuracy_score, f1_score

target = np.array([0] * 10 + [1] * 10)
print(target)

pred = np.array([0,0,0,0,0,1,1,1,0,0,1,1,1,1,1,1,0,0,1,1])
print(pred)

print(confusion_matrix(target, pred))

print('정밀도 : ', precision_score(target, pred))
print('재현율 : ', recall_score(target, pred))

print('정확도 : ', accuracy_score(target, pred))
print('F1 점수 : ', f1_score(target, pred))
