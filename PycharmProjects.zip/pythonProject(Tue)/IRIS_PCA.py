# # KNN으로 성능확인
# from sklearn.decomposition import PCA
# from sklearn.preprocessing import StandardScaler
# from sklearn import datasets
# import numpy as np
# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns
# from sklearn.neighbors import KNeighborsClassifier
# from sklearn.model_selection import train_test_split
# from sklearn.metrics import accuracy_score
#
# data = datasets.load_iris()
# # print(data)
#
# df = pd.DataFrame(data['data'], columns=data['feature_names'])
# df['target'] = data['target']
# df.head()
#
# # plt.figure(figsize=(8,8))
# ax = sns.pairplot(df, hue='target')
# plt.show()
#
# x_df = df.iloc[:,[0,1,2,3]]
# print(x_df.mean(axis=0))
# print(x_df.var(axis=0))
#
# scalerX = StandardScaler()
# scalerX.fit(data.data)
# x_std = scalerX.transform(data.data)
# print(x_std)
#
# pca = PCA()
# pca.fit(x_std)
#
# # 주성분 분산
# print(pca.explained_variance_)
# # 주성분 분산비율
# print(pca.explained_variance_ratio_)
#
# plt.plot(pca.explained_variance_,'o-')
# plt.title('ScreePlot')
# plt.xlabel('Principal Component')
# plt.ylabel('Variance Ratio')
# plt.show()
#
# z = pca.fit_transform(x_std)
# z_df = pd.DataFrame(data=z, columns=['PC1', 'PC2', 'PC3', 'PC4'])
# print(z_df.head())
#
# z_df['target'] = data['target']
#
# # plt.figure(figsize=(8,8))
# ax = sns.pairplot(df,hue='target')
# plt.show()
#
# loadings = pca.components_
# print(loadings)
#
# plt.scatter(loadings[:,0], loadings[:,1], color='w')
# plt.xlabel('PC1')
# plt.ylabel('PC1')
# plt.xlim(-2,2)
# plt.ylim(-2,2)
#
# rows, colums = loadings.shape
# rows_names = ['x1', 'x2', 'x3', 'x4']
# for i in range(rows):
#     plt.arrow(0,0,loadings[i,0], loadings[i,1],
#               color='r', alpha=0.5)
#     plt.text(loadings[i,0]*1.2, loadings[i,1]*1.2,
#              rows_names[i],color='g',
#              ha='center', va = 'center')
# plt.show()
#
# # # 상위 세 개의 주성분 선택
# # selected_components = z[:, :3]
# #
# # # 데이터 분할
# # X_train, X_test, y_train, y_test = train_test_split(selected_components, data.target, test_size=0.3, random_state=1234)
# #
# # # KNN 모델 생성 및 학습
# # knn = KNeighborsClassifier()
# # knn.fit(X_train, y_train)
# #
# # # 테스트 데이터로 예측
# # y_pred = knn.predict(X_test)
# #
# # # 정확도 평가
# # accuracy = accuracy_score(y_test, y_pred)
# # print("Accuracy:", accuracy)
#

#

from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn import datasets
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

data = datasets.load_iris()
# print(data)

df = pd.DataFrame(data['data'], columns=data['feature_names'])
df['target'] = data['target']
df.head()

# plt.figure(figsize=(8,8))
ax = sns.pairplot(df, hue='target')
plt.show()

x_df = df.iloc[:, [0, 1, 2, 3]]
print(x_df.mean(axis=0))
print(x_df.var(axis=0))

scalerX = StandardScaler()
scalerX.fit(data.data)
x_std = scalerX.transform(data.data)
print(x_std)

pca = PCA()
pca.fit(x_std)

# 주성분 분산
print(pca.explained_variance_)
# 주성분 분산비율
print(pca.explained_variance_ratio_)

plt.plot(pca.explained_variance_, 'o-')
plt.title('ScreePlot')
plt.xlabel('Principal Component')
plt.ylabel('Variance Ratio')
plt.show()

z = pca.fit_transform(x_std)
z_df = pd.DataFrame(data=z, columns=['PC1', 'PC2', 'PC3', 'PC4'])
print(z_df.head())

z_df['target'] = data['target']

# plt.figure(figsize=(8,8))
ax = sns.pairplot(df, hue='target')
plt.show()

loadings = pca.components_
print(loadings)

plt.scatter(loadings[:, 0], loadings[:, 1], color='w')
plt.xlabel('PC1')
plt.ylabel('PC1')
plt.xlim(-2, 2)
plt.ylim(-2, 2)

rows, colums = loadings.shape
rows_names = ['x1', 'x2', 'x3', 'x4']
for i in range(rows):
    plt.arrow(0, 0, loadings[i, 0], loadings[i, 1],
              color='r', alpha=0.5)
    plt.text(loadings[i, 0] * 1.2, loadings[i, 1] * 1.2,
             rows_names[i], color='g',
             ha='center', va='center')
plt.show()

# KNN 분류 모델 추가
X_train, X_test, y_train, y_test = train_test_split(z_df[['PC1', 'PC2', 'PC3', 'PC4']], z_df['target'], test_size=0.3,
                                                    random_state=1234)

train_accuracy = []
test_accuracy = []
best_model = {"k": 0, "score": 0}

# 최근접 이웃의 수: 1~15
neighbors = range(1, 16)
for k in neighbors:
    # 모형화
    knn = KNeighborsClassifier(n_neighbors=k)
    # 학습
    knn.fit(X_train, y_train)

    # 학습 데이터의 분류 정확도
    score = knn.score(X_train, y_train)
    train_accuracy.append(score)

    # 테스트 데이터의 분류 정확도
    score = knn.score(X_test, y_test)
    test_accuracy.append(score)

    if best_model["score"] < score:
        best_model["k"] = k
        best_model["score"] = score

print(f"K값: {best_model['k']}, Score: {best_model['score']}")

# K의 크기에 따른 분류 정확도 변화
plt.plot(neighbors, train_accuracy, label="train")
plt.plot(neighbors, test_accuracy, label="test")
plt.xlabel("K")
plt.ylabel("Accuracy")
plt.legend()
plt.show()

