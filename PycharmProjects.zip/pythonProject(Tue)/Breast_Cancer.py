from sklearn.datasets import load_breast_cancer
from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data = load_breast_cancer(as_frame=True)
# print(data.frame)
# print('-------------------------------------')
# print(data.data)
# print('-------------------------------------')
# print(data.target)
# print('-------------------------------------')
# print(data.DESCR)
# print('-------------------------------------')
# print(data.feature_names)
# print('-------------------------------------')
# print(data.target_names)
# print('-------------------------------------')
print(data)

data_mean = data.frame[['mean radius', 'mean texture', 'mean perimeter',
                        'mean area', 'target']]
sns.pairplot(data_mean, hue='target')
# plt.show()

X_train, X_test, y_train, y_test = train_test_split(data.data, data.target,test_size=0.3, random_state=4321)

print(X_train.shape)
print(X_test.shape)
print(y_train.shape)
print(y_test.shape)
print('-------------------------------------')

scalerX = StandardScaler()
scalerX.fit(X_train)
X_train_std = scalerX.transform(X_train)
print(X_train_std)
print('-------------------------------------')

X_test_std = scalerX.transform(X_test)
print(X_test_std)
print('-------------------------------------')

train_accuracy = []
test_accuracy = []
neighbors = range(2, 16)
for k in neighbors:
    knn = KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train_std, y_train)

    score = knn.score(X_train_std, y_train)
    train_accuracy.append(score)

    score = knn.score(X_test_std, y_test)
    test_accuracy.append(score)

plt.plot(neighbors, train_accuracy, label="train")
plt.plot(neighbors, test_accuracy, label="test")
plt.xlabel("K")
plt.ylabel("Accuracy")
plt.legend()
# plt.show()

test_accuracy

K = 3
knn = KNeighborsClassifier(n_neighbors=K)
knn.fit(X_train_std, y_train)

y_pred = knn.predict(X_test_std)
print(y_pred)
print('-------------------------------------')

cf = confusion_matrix(y_test, y_pred)
print(cf)
print('-------------------------------------')

knn.score(X_test_std, y_test)

from sklearn.decomposition import PCA

df = pd.DataFrame(data['data'], columns = data['feature_names'])
df['target'] = data['target']

scalerX = StandardScaler()
scalerX.fit(data.data)
x_std = scalerX.transform(data.data)
print(x_std)

pca = PCA()
pca.fit(x_std)

print(pca.explained_variance_)
print("===============================")
print(pca.explained_variance_ratio_)
print("===============================")

num_features = data.feature_names.shape[0]  # or len(data.feature_names)
print("열의 개수:", num_features)

# z = pca.fit_transform(x_std)
# z_df = pd.DataFrame(data=z, columns=[])
# print(z_df.head())

# 훈련 및 테스트 정확도 출력
print("훈련 정확도:", train_accuracy[-1])
print("테스트 정확도:", test_accuracy[-1])

# 최적의 K 값에 대한 정확도 출력
print("K 훈련 정확도:", knn.score(X_train_std, y_train))
print("K 테스트 정확도:", knn.score(X_test_std, y_test))

# # 혼동 행렬 출력
# print("혼동 행렬:")
# print(cf)

# K 값에 따른 테스트 정확도 출력
print("K값 \t 훈련 정확도 \t 테스트 정확도")
for i, k in enumerate(neighbors):
  print(f"{k} \t {train_accuracy[i]:.4f} \t {test_accuracy[i]:.4f}")

# 최적의 K 값 찾기
best_k_idx = test_accuracy.index(max(test_accuracy))
best_k = neighbors[best_k_idx]
best_test_accuracy = test_accuracy[best_k_idx]

print("===============================")
print(f"최적 K 값: {best_k}")
print(f"최적 K 값의 테스트 정확도: {best_test_accuracy:.4f}")