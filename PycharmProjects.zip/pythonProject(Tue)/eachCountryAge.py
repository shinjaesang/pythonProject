# import pandas as pd
# import matplotlib.pyplot as plt
# import seaborn as sns
# from sklearn.linear_model import LinearRegression
# from sklearn.metrics import mean_squared_error
# from sklearn.model_selection import train_test_split
#
# data_loc = 'https://github.com/dknife/ML/raw/main/data/'
# life = pd.read_csv(data_loc + 'life_expectancy.csv')
# print(life.head())
#
# life = life[['Life expectancy', 'Year', 'Alcohol',
#              'Percentage expenditure', 'Total expenditure',
#              'Hepatitis B', 'Measles', 'Polio', 'BMI', 'GDP',
#              'Thinness 1-19 years', 'Thinness 5-9 years']]
# # pd.set_option('display.max_columns', None)
# # pd.set_option('display.max_rows', None)
# print(life)
# print(life.shape)
# print(life.isnull().sum())
# life.dropna(inplace=True)
# print(life.shape)
# # 위에 까지가 데이터 전처리 과정
#
# # 히트맵 함수를 이용하여 상관행렬 형성
# sns.set(rc={'figure.figsize':(12,10)}) #상관행렬 가시
# correlation_matrix = life.corr().round(2) #상관행렬 생성
# sns.heatmap(data=correlation_matrix, annot=True)
# plt.show()
#
# # 특징들의 상관 쌍 그림을 확인하고 중요 측징 추출하기
# sns.pairplot(life[['Life expectancy', 'Alcohol',
#              'Percentage expenditure', 'Polio', 'BMI', 'GDP',
#              'Thinness 1-19 years']])
# plt.show()
#
# X = life[['Life expectancy', 'Alcohol',
#              'Percentage expenditure', 'Polio', 'BMI', 'GDP',
#              'Thinness 1-19 years']]
# y = life['Life expectancy']
# print(X)
# print(y)
#
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
# #X, y에 담긴 데이터 가운데 80%는 훈련용(X,y_train), 나머지 20%는 검증용(X,y_test)으로 나눔
#
# # 사이킷런의 LinearRegression 모델을 사용하여 학습을 진행
# lin_model = LinearRegression()
# lin_model.fit(X_train, y_train)
#
# y_hat_train = lin_model.predict(X_train)
#
# plt.scatter(y_train, y_hat_train)
# xy_range = [40, 100]
# plt.plot(xy_range, xy_range)
# plt.show()
#
# y_hat_test = lin_model.predict(X_test)
#
# plt.scatter(y_test, y_hat_test)
# plt.plot(xy_range, xy_range)
# plt.show()
#
#
# print('Mean squared error:', mean_squared_error(y_test, y_hat_test))

# 효제형 코드
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, mean_absolute_error
from sklearn.preprocessing import normalize
from sklearn.preprocessing import StandardScaler

data_loc = 'http://github.com/dknife/ML/raw/main/data/'
life = pd.read_csv(data_loc + 'life_expectancy.csv')
print(life.head())

# life = life[['Life expectancy', 'Year', 'Alcohol',
#              'Percentage expenditure', 'Total expenditure',
#              'Hepatitis B', 'Measles', 'Polio', 'BMI', 'GDP',
#              'Thinness 1-19 years', 'Thinness  5-9 years']]

life = life[['Life expectancy', 'Year', 'Alcohol', 'Percentage expenditure', 'Total expenditure',
             'Hepatitis B', 'Measles', 'Polio', 'BMI', 'GDP', 'Thinness 1-19 years', 'Thinness 5-9 years']]

print(life)

print(life.shape)
print(life.isnull().sum)

life.dropna(inplace=True)  # dropna를 하게되면 데이터의 원본 자체가 변형됨.
print(life.shape)

sns.set(rc={'figure.figsize': (12, 10)})  # 상관행렬 가시
correlation_matrix = life.corr().round(2)  # 상관행렬 생성
sns.heatmap(data=correlation_matrix, annot=True)
plt.show()

sns.pairplot(life[['Life expectancy', 'Alcohol', 'Percentage expenditure',
                   'Measles', 'Polio', 'BMI', 'GDP', 'Thinness 1-19 years']])
plt.show()

X = life[['Alcohol', 'Percentage expenditure', 'Polio',
          'BMI', 'GDP', 'Thinness 1-19 years']]
y = life['Life expectancy']
print(X)
print(y)  ######
# ###### 데이터를 불러오고 데이터의 값들을 확인해봄. 상관행렬을 이용해서 연관있는 것들을 출력해봄.
## 그런 다음 훈련과 학습을 통해 검증용도 나눌 단계.

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

lin_model = LinearRegression()
lin_model.fit(X_train, y_train)

y_hat_train = lin_model.predict(X_train)
plt.scatter(y_train, y_hat_train)
xy_range = [40, 100]
plt.plot(xy_range, xy_range)
plt.show()

y_hat_test = lin_model.predict(X_test)

plt.scatter(y_test, y_hat_test)
plt.plot(xy_range, xy_range)
plt.show()

print('Mean squared error:', mean_squared_error(y_test, y_hat_test))
print('Mean absolute error:', mean_absolute_error(y_test, y_hat_test))

n_X = normalize(X, axis = 0)

nXtrain, nXtest, y_train, y_test = train_test_split(n_X, y, test_size=0.2)
lin_model.fit(nXtrain, y_train)

y_hat_train = lin_model.predict(nXtrain)
y_hat_test = lin_model.predict(nXtest)
plt.scatter(y_train, y_hat_train, color='r')
plt.scatter(y_test, y_hat_test, color='b')
plt.plot(xy_range, xy_range)
plt.show()

print('Mean squared error:', mean_squared_error(y_test, y_hat_test))#평균 제곱 오차를 계산
print('Mean absolute error:', mean_absolute_error(y_test, y_hat_test))

scaler = StandardScaler()
s_X = scaler.fit_transform(X)

plt.hist(n_X, bins=5)

