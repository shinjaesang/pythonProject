import numpy as np
values = np.array([10.0, 20.0, 30.0])
weights = np.array([0.5, 0.25, 0.25])
print("weights :", weights)
print("via weights and dot : ", np.dot(weights, values))