import numpy as np
from sklearn.datasets import load_iris                ##여기바꿈
from sklearn.neighbors import  KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import ConfusionMatrixDisplay
from sklearn.metrics import confusion_matrix

import pandas as pd
import matplotlib.pyplot as plt
import  seaborn as sns

##2. 데이터 준비
#데이터 불러오기
data = load_iris(as_frame=True)

# #데이터프레임 출력
# print(data.frame)

##3.탐색적 데이터분석
#데이터 세트 개요
print(data.DESCR)
print(data.target_names)
#변수간 산포도

X =data.frame[['sepal length (cm)','sepal width (cm)','petal length (cm)','petal width (cm)','target']] ##여기바꿈


correlation_matrix = X.corr().round(2)  #상관행렬 생성
sns.heatmap(data = correlation_matrix, annot =True)
plt.show() #colab 등 노트북 환경에서는 필요없지만, 콘솔환경등에서는 필요


y = data.frame[['petal length (cm)','petal width (cm)','target']]
correlation_matrix = y.corr().round(2)  #상관행렬 생성
sns.heatmap(data = correlation_matrix, annot =True)
plt.show() #colab 등 노트북 환경에서는 필요없지만, 콘솔환경등에서는 필요


##4단계 데이터 분리
#학습용과 테스트데이터분리
X_train, X_test, y_train, y_test = train_test_split(data.frame[['petal length (cm)', 'petal width (cm)']], data.target, test_size=0.3, random_state=1234)


##5.피처 스케일링
#피처스케일링:학습데이터
scalerX =StandardScaler()
scalerX.fit(X_train)
X_train_std =scalerX.transform(X_train)

#피처스케일링: 테스트데이터
X_test_std = scalerX.transform(X_test)


##6.모형화 및 학습
##최근접이웃수결정
#학습용데이터의분류정확도
train_accuracy =[]

#테스트데이터의 분류정확도
test_accuracy =[]

best_model = {"k":0,"score":0.0}

#최근접이웃의수: 1~15
neighbors =range(1,16)
for k in neighbors:
    #모형화
    knn=KNeighborsClassifier(n_neighbors=k)
    #학습
    knn.fit(X_train_std,y_train)
    #학습데이터의분류정확도
    score =knn.score(X_train_std, y_train)
    train_accuracy.append(score)

    #테스트데이터의분류정확도
    score=knn.score(X_test_std,y_test)
    test_accuracy.append(score)
    if best_model["score"] < score:
        best_model["k"] = k
        best_model["score"] = score
print(f"K값:{best_model['k']},Score:{best_model['score']}")
#K의 크키게 따른 분류 정확도 변화
plt.plot(neighbors,train_accuracy,label="train")
plt.plot(neighbors,test_accuracy,label="test")
plt.xlabel("K")
plt.ylabel("Accuracy")
plt.legend()
plt.show()

#테스트 데이터의 분류 정확도
print(test_accuracy)

#모형화
K= 4
knn =KNeighborsClassifier(n_neighbors=K)

#학습
knn.fit(X_train_std,y_train)


#예측
y_pred =knn.predict(X_test_std)
print(y_pred)

#confusion_matrix
cf =confusion_matrix(y_test,y_pred)
print(cf)
ConfusionMatrixDisplay.from_predictions(y_test,y_pred)
plt.show()

#테스트데이터에 대한 정확도
dsd=knn.score(X_test_std,y_test)
print(dsd)