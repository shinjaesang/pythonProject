from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

x = np.array([[50, 73], [65, 75], [75, 80], [80, 82], [95, 85]])
print(x)

plt.scatter(x[:, 0], x[:, 1])
plt.xlabel('x1')
plt.ylabel('x2')
plt.xlim(0, 100)
plt.ylim(0, 100)
plt.show()
# 열별 평균
print("==========================")
print(np.mean(x,axis=0))
# 열별 분산
print(np.var(x,axis=0))

print("==========================")
# 데이터 표준화
scalerX = StandardScaler()
scalerX.fit(x)
x_std = scalerX.transform(x)
# 데이터프레임으로 변환 및 열이름 설정
print(x_std)

# 표준화된 데잍의 1열(x1)과 2열(x2)의 산포도
plt.scatter(x_std[:,0], x_std[:,1])
plt.xlabel('x1')
plt.ylabel('x2')
plt.xlim(-3,3)
plt.ylim(-3,3)
plt.show()

# 열별 평균
print("==========================")
print(np.mean(x_std,axis=0))
# 모공분산행렬
print(np.cov(x_std[:,0], x_std[:,1], ddof=0))

# 주성분의 수 설정
pca = PCA(n_components=2)
# 주성분분석
pca.fit(x_std)

print("==========================")
# 주성분 분산
print(pca.explained_variance_)
# 주성분 분산비율
print(pca.explained_variance_ratio_)

print("==========================")
# 주성분으로 데이터 변환
z = pca.fit_transform(x_std)
print(z)

# 주성분 좌표계의 분포
plt.scatter(z[:,0], z[:,1])
plt.xlabel('PC1')
plt.ylabel('PC2')
plt.xlim(-2.5,2.5)
plt.ylim(-2.5,2.5)
plt.show()

print("==========================")
# 주성분 로깅(고유벡터)
loadings = pca.components_
print(loadings)

# 주성분 로딩 분포
plt.scatter(loadings[:,0], loadings[:,1], color='w')
plt.xlabel('PC1')
plt.ylabel('PC2')
plt.xlim(-2,2)
plt.ylim(-2,2)


# 행과 열의 수
rows,columns = loadings.shape
# 행의 이름
rows_names = ['x1','x2']
for i in range(rows):
    # 선 긋기
    plt.arrow(0,0, loadings[i,0], loadings[i,1],
              color='r',alpha=0.5)
    # 변수명 출력
    plt.text( loadings[i,0], loadings[i,1] * 1.2,
              rows_names[i],color='g',
              ha='center', va='center')
plt.show()