import numpy as np
quantity = np.array([2,12,3])
costs = np.array([12.5, 0.5, 1.75])
print(quantity.dot(costs))
print(np.dot(quantity, costs))
print(quantity @costs)