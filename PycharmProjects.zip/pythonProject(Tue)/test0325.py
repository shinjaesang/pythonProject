from sklearn.neighbors import KNeighborsClassifier
from sklearn.preprocessing import StandardScaler
import  numpy as np
import  matplotlib.pyplot as plt

# 학습용 데이터(기존 개체)
# 입력
X_train = np.array([[25,25],
                   [33,30],
                   [38,30],
                   [45,35],
                   [28,40]])
# 라벨
y_train = np.array([0,0,1,1,0])
# 테스트용 데이터 (새로운 개체)
# 입력
X_test = np.array([[30,35]])

# 산포도
# 학습용 데이터
plt.scatter(X_train[:,0], X_train[:,1], c=y_train)

# 테스트용 데이터
plt.scatter(X_test[:, 0], X_test[:, 1], c='red', marker='D', s=100) # X, X, 색, 마커, 크기
plt.xlabel('x1')
plt.ylabel('x2')
plt.show()

scalerX = StandardScaler()
scalerX.fit(X_train)
X_train_std = scalerX.transform(X_train)
print(X_train_std)
print('-------------------------------------')

X_test_std = scalerX.transform(X_test)
print(X_test_std)
print('-------------------------------------')

knn = KNeighborsClassifier(n_neighbors=3, metric='euclidean')

knn.fit(X_train_std, y_train)

pred = knn.predict(X_test_std)
print(pred)
print('-------------------------------------')

print(knn.predict_proba(X_test_std))
print('-------------------------------------')
