import numpy as np
from tensorflow.keras.datasets import mnist
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense

# Load MNIST data
(X_train, y_train), (X_test, y_test) = mnist.load_data()

# Flatten the images
X_train = X_train.reshape(X_train.shape[0], -1)
X_test = X_test.reshape(X_test.shape[0], -1)

# Create binary labels: 1 for '5', 0 for others
y_train_binary = (y_train == 5).astype(np.int)
y_test_binary = (y_test == 5).astype(np.int)

# Standardize the data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Logistic Regression
log_reg = LogisticRegression(max_iter=10000)
log_reg.fit(X_train_scaled, y_train_binary)
y_pred_log_reg = log_reg.predict(X_test_scaled)

print("Logistic Regression")
print(classification_report(y_test_binary, y_pred_log_reg))

# Support Vector Machine
svm_clf = SVC()
svm_clf.fit(X_train_scaled, y_train_binary)
y_pred_svm = svm_clf.predict(X_test_scaled)

print("Support Vector Machine")
print(classification_report(y_test_binary, y_pred_svm))

# Random Forest
rf_clf = RandomForestClassifier(n_estimators=100)
rf_clf.fit(X_train_scaled, y_train_binary)
y_pred_rf = rf_clf.predict(X_test_scaled)

print("Random Forest")
print(classification_report(y_test_binary, y_pred_rf))

# Simple Neural Network
model = Sequential([
    Dense(128, activation='relu', input_shape=(784,)),
    Dense(64, activation='relu'),
    Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam', loss='binary_crossentropy', metrics=['accuracy'])

# Train the model
model.fit(X_train_scaled, y_train_binary, epochs=10, batch_size=32, validation_split=0.1)

# Evaluate the model
y_pred_nn = (model.predict(X_test_scaled) > 0.5).astype("int32")

print("Neural Network")
print(classification_report(y_test_binary, y_pred_nn))
